const helloMessage = "Greetings! Let us begin!";

module.exports = { helloMessage };
