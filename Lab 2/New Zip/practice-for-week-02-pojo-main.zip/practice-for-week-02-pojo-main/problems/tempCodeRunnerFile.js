
 The function should return an array containing the
corresponding values of the objects for the given key.